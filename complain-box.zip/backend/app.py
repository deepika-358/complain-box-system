from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from config import Config
from database import init_db

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Extensions
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    JWTManager(app)

    # Database
    init_db(app)

    # Blueprints
    from routes.complaints import complaints_bp
    from routes.auth import auth_bp

    app.register_blueprint(complaints_bp)
    app.register_blueprint(auth_bp)

    @app.route("/")
    def index():
        return {"message": "Complain Box API is running!", "version": "1.0.0"}

    return app


if __name__ == "__main__":
    app = create_app()
    print("\n" + "="*50)
    print("  [*] Complain Box Backend Running!")
    print("  [*] API: http://localhost:5000")
    print("  [*] Default Admin: shine / 262425")
    print("="*50 + "\n")
    app.run(debug=True, port=5000, host="0.0.0.0")
