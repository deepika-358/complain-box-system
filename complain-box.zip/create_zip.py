﻿import os, zipfile
root = r"c:\Users\deepi\OneDrive\Desktop\complain box"
zip_path = os.path.join(root, "complain-box.zip")
with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for folder, dirs, files in os.walk(root):
        if folder.startswith(os.path.join(root, ".venv")):
            continue
        for f in files:
            if f == "complain_box.db" or f == "complain-box.zip":
                continue
            full = os.path.join(folder, f)
            rel = os.path.relpath(full, root)
            z.write(full, rel)
print("created", zip_path)
